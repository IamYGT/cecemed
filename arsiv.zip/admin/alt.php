 <div class="footer">
            <div class="copyright">
                <p>Copyright © Designed &amp; Developed by <a href="http://www.memsidea.com/" target="_blank">Memsidea Group</a> 2020</p>
            </div>
        </div>