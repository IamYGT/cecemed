<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link rel="apple-touch-icon" sizes="180x180" href="<?php echo $ayarlar["strURL"]; ?>/images/ikonlar/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="<?php echo $ayarlar["strURL"]; ?>/images/ikonlar/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="<?php echo $ayarlar["strURL"]; ?>/images/ikonlar/favicon-16x16.png">
<link rel="manifest" href="<?php echo $ayarlar["strURL"]; ?>/images/ikonlar/site.webmanifest">
<link rel="mask-icon" href="<?php echo $ayarlar["strURL"]; ?>/images/ikonlar/safari-pinned-tab.svg" color="#5bbad5">
<link rel="shortcut icon" href="<?php echo $ayarlar["strURL"]; ?>/images/ikonlar/favicon.ico">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-config" content="<?php echo $ayarlar["strURL"]; ?>/images/ikonlar/browserconfig.xml">
<meta name="theme-color" content="#0d98af">
<link rel="stylesheet" type="text/css" href="<?php echo $ayarlar["strURL"]; ?>/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo $ayarlar["strURL"]; ?>/css/font-awesome.css" media="all">
<link rel="stylesheet" type="text/css" href="<?php echo $ayarlar["strURL"]; ?>/css/simple-line-icons.css" media="all">
<link rel="stylesheet" type="text/css" href="<?php echo $ayarlar["strURL"]; ?>/css/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="<?php echo $ayarlar["strURL"]; ?>/css/owl.theme.css">
<link rel="stylesheet" type="text/css" href="<?php echo $ayarlar["strURL"]; ?>/css/jquery.bxslider.css">
<link rel="stylesheet" type="text/css" href="<?php echo $ayarlar["strURL"]; ?>/css/jquery.mobile-menu.css">
<link rel="stylesheet" type="text/css" href="<?php echo $ayarlar["strURL"]; ?>/css/revslider.css">
<link rel="stylesheet" type="text/css" href="<?php echo $ayarlar["strURL"]; ?>/css/style.css" media="all">
<link rel="stylesheet" type="text/css" href="<?php echo $ayarlar["strURL"]; ?>/css/blog.css" media="all">
<link rel="stylesheet" type="text/css" href="<?php echo $ayarlar["strURL"]; ?>/css/responsive.css" media="all">
<link rel="stylesheet" href="https://cdn.linearicons.com/free/1.0.0/icon-font.min.css">
<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Lustria" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Ubuntu:300,300i,400,500,500i,700" rel="stylesheet">